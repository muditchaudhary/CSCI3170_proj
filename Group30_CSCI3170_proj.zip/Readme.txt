Group 30

Group Members:

1) Mudit Chaudhary: 1155085166
2) Anju Otsuka: 1155086631
3) Rustami Ubaydullo: 1155102622

How to compile and run:
1) Extract teh ZIP file
2) Navigate to the dist folder: eg cd M:\dbProject\CSCI3170_proj\CSCI3170\dist\
3) Run java -jar CSCI3170.jar
